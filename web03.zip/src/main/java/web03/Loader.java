package web03;


import java.rmi.ServerException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;


public class Loader extends HttpServlet {
	@Override
	public void init(ServletConfig config) throws ServletException{
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			System.out.println("드라이버로딩");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new ServletException();
		}
	}
}
